//
//  FechasCollectionViewCell.swift
//  producto
//
//  Created by macbook on 21/11/18.
//  Copyright © 2018 potato. All rights reserved.
//

import UIKit

class FechasCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var fechalabel: UILabel!
}
