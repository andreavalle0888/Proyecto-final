//
//  daySelected.swift
//  producto
//
//  Created by macbook on 26/11/18.
//  Copyright © 2018 potato. All rights reserved.
//

import Foundation

struct daySelected: Codable {
    var day: String
    var month: String
    var year: String
    var description: String
}
